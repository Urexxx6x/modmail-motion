module.exports = {
  token: 'ODE0MTM3NDA4OTQ4OTI4NTMy.YDZejA.SaP4nMjHJKu7K9IkuE3bz52Pozw',
  databaseToken: 'mongodb+srv://discordbot:rTBUB6Gis2ndGgmU@discordbot.9usmv.mongodb.net/discordbot?retryWrites=true&w=majority',

  mainGuild: '741963009626472468',
  logChannel: '813115920598695977',
  mailChannel: '795592461565034506',
  modRoles: ['795592447128240128'],

  status: 'discord.gg/motion',
  color: 0x1a9c3d,
  prefix: 'm!',
  msgPrefix: 'Staff',
};
